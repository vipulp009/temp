// dependencies
var AWS = require('aws-sdk');
var proxy = require('proxy-agent');
const proxyURL = process.env.HTTP_PROXY_URL;

AWS.config.update({ httpOptions: { agent: proxy(proxyURL) } });

var util = require('util');
var async = require('async');
var Redis = require('ioredis');

// get reference to S3 client 
var s3 = new AWS.S3();

//var redis = new Redis.Cluster(['edfc-redis.pwp4j0.clustercfg.use2.cache.amazonaws.com:6379'], {
var redis = new Redis.Cluster([process.env.REDIS_URL], {
  scaleReads: 'slave'
});

const NAME_SEPERATOR = ":";

exports.handler = function(event, context, callback) {
    // Read options from the event.
    console.log("Reading options from event:\n", util.inspect(event, {depth: 5}));
    var srcBucket = event.Records[0].s3.bucket.name;
    // Object key may have spaces or unicode non-ASCII characters.
    var srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));  
    console.log("Event object is: ",event);
    // Download the data from S3
    async.waterfall([
        // Download the data from S3 into a buffer.
        function(callbackW) {
            var options = {Bucket: srcBucket, Key: srcKey};
            s3.getObject(options, function(err, data){
                if(err) callbackW(err);
                else {
                    console.log("Bucket file content: ", data);
                    callbackW(null, data.Body.toString());
                }
            });
        },
        // upload to redis
        function(content, callbackW){
            console.log("Uploading file content to redis: ", content);
            //var key = srcBucket + NAME_SEPERATOR + srcKey;
            var key = srcKey;
            console.log("Redis Key is: "+key);
            redis.set( key , content);
            callbackW();
        }
    ], function (err) {
        if (err) {
            console.error('Error: ' + err);
        } else {
            console.log('Success in downloading data from S3');
        }
        callback(null, "Success");
    });
};
