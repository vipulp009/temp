var AWS = require('aws-sdk');

var proxy = require('proxy-agent');

const proxyURL = process.env.HTTP_PROXY_URL;
AWS.config.update({ httpOptions: { agent: proxy(proxyURL) } });

var util = require('util');
var Redis = require('ioredis');

var s3 = new AWS.S3();

var redis = new Redis.Cluster([process.env.REDIS_URL], {
  scaleReads: 'slave'
});

const NAME_SEPERATOR = ":";

exports.handler = function(event, context, callback) {
  // Read options from the event.
  console.log("Reading options from event:\n", util.inspect(event, {depth: 5}));
  var srcBucket = event.Records[0].s3.bucket.name;
  // Object key may have spaces or unicode non-ASCII characters.
  var srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));  

  // Download the data from S3
  //var key = srcBucket + NAME_SEPERATOR + srcKey;
  var key = srcKey;
  console.log("Deleting redis key with key: ", key);
  redis.del( key);
  callback(null, "Success");
};